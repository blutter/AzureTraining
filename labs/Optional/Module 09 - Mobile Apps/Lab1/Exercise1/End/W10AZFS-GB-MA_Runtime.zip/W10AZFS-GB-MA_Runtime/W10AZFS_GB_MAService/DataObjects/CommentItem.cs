﻿
using Microsoft.Azure.Mobile.Server;

namespace W10AZFS_GB_MAService.DataObjects
{
    public class CommentItem : EntityData
    {
        public string Description { get; set; }

        public string Name { get; set; }
    }
}
