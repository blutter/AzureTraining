The 0.2.575 version of the preview Microsoft.Azure.Mobile.Server.* packages includes breaking changes to the Server SDK.

You can read more about the changes and how to update your code at http://go.microsoft.com/fwlink/?LinkId=625008.

The full Server SDK changelog can be found at http://go.microsoft.com/fwlink/?LinkId=625009.