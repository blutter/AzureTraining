﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.System;
using Windows.UI.Popups;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.MobileServices;
using Microsoft.WindowsAzure.MobileServices.SQLiteStore;  // offline sync
using Microsoft.WindowsAzure.MobileServices.Sync;         // offline sync


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace AzureGuestbook
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }


        private MobileServiceCollection<CommentItem, CommentItem> items;
        //private IMobileServiceTable<CommentItem> commentTable = App.MobileService.GetTable<CommentItem>();
        private IMobileServiceSyncTable<CommentItem> commentTable = App.MobileService.GetSyncTable<CommentItem>(); // offline sync
        private async Task InsertCommentItem(CommentItem commentItem)
        {
            // This code inserts a new CommentItem into the database. When the operation completes
            // and Mobile Services has assigned an Id, the item is added to the CollectionView
            await commentTable.InsertAsync(commentItem);
            items.Add(commentItem);
            await RefreshCommentItems();

            //await SyncAsync(); // offline sync
        }

        private async Task RefreshCommentItems()
        {
            MobileServiceInvalidOperationException exception = null;
            try
            {
                IReadOnlyList<User> users = await User.FindAllAsync();
                string displayName = "";
                foreach (User u in users)
                {
                    var pFirstName = await u.GetPropertyAsync(KnownUserProperties.FirstName);
                    var pLastName = await u.GetPropertyAsync(KnownUserProperties.LastName);
                    displayName = string.Format("{0} {1}", pFirstName, pLastName);
                }

                // This code refreshes the entries in the list view by querying the CommentItems table.
                items = await commentTable
                    //.Where(commentItem => commentItem.Name == displayName)
                    .OrderByDescending(commentItem => commentItem.Id)
                    .ToCollectionAsync();
            }
            catch (MobileServiceInvalidOperationException e)
            {
                exception = e;
            }

            if (exception != null)
            {
                await new MessageDialog(exception.Message, "Error loading items").ShowAsync();
            }
            else
            {
                ltvGuestbook.ItemsSource = items;
                this.SubmitButton.IsEnabled = true;
            }
        }

        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            RefreshButton.IsEnabled = false;

            await SyncAsync(); // offline sync
            await RefreshCommentItems();

            RefreshButton.IsEnabled = true;
        }

        private async void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            IReadOnlyList<User> users = await User.FindAllAsync();
            string displayName = "";
            foreach (User u in users)
            {
                var pFirstName = await u.GetPropertyAsync(KnownUserProperties.FirstName);
                var pLastName = await u.GetPropertyAsync(KnownUserProperties.LastName);
                displayName = string.Format("{0} {1}", pFirstName, pLastName);
            }
            var num = 0;
            if (items.Count > 0)
            {
                var lastComment = items.OrderByDescending(item => item.Id).First();
                num = Convert.ToInt32(lastComment.Id) + 1;
            }

            var commentItem = new CommentItem { Id = num.ToString("D3"), Description = CommentTextBox.Text, Name = displayName };
            await InsertCommentItem(commentItem);
        }

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await InitLocalStoreAsync(); // offline sync
            await RefreshCommentItems();
        }

        #region Offline sync

        private async Task InitLocalStoreAsync()
        {
            if (!App.MobileService.SyncContext.IsInitialized)
            {
                var store = new MobileServiceSQLiteStore("localstore.db");
                store.DefineTable<CommentItem>();
                await App.MobileService.SyncContext.InitializeAsync(store);
            }

            //await SyncAsync();
        }

        private async Task SyncAsync()
        {
            String errorString = null;

            try
            {
                await App.MobileService.SyncContext.PushAsync();
                await commentTable.PullAsync("commentItems", commentTable.CreateQuery()); // first param is query ID, used for incremental sync
            }

            catch (MobileServicePushFailedException ex)
            {
                errorString = "Push failed because of sync errors. You may be offine.\nMessage: " +
                    ex.Message + "\nPushResult.Status: " + ex.PushResult.Status.ToString();
            }
            catch (Exception ex)
            {
                errorString = "Pull failed: " + ex.Message +
                    "\n\nIf you are still in an offline scenario, " +
                    "you can try your Pull again when connected with your Mobile Service.";
            }

            if (errorString != null)
            {
                MessageDialog d = new MessageDialog(errorString);
                await d.ShowAsync();
            }
        }


        #endregion

    }
}
