﻿using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.OData;
using Microsoft.Azure.Mobile.Server;
using W10AZFS_GB_MAService.DataObjects;
using W10AZFS_GB_MAService.Models;
using System.Collections.Generic;
using Microsoft.Azure.NotificationHubs;
using Microsoft.Azure.Mobile.Server.Config;


namespace W10AZFS_GB_MAService.Controllers
{
    [Authorize]
    public class CommentItemController : TableController<CommentItem>
    {
        protected override void Initialize(HttpControllerContext controllerContext)
        {
            base.Initialize(controllerContext);
            W10AZFS_GB_MAContext context = new W10AZFS_GB_MAContext();
            DomainManager = new EntityDomainManager<CommentItem>(context, Request);
        }

        // GET tables/CommentItem
        public IQueryable<CommentItem> GetAllCommentItem()
        {
            return Query(); 
        }

        // GET tables/CommentItem/48D68C86-6EA6-4C25-AA33-223FC9A27959
        public SingleResult<CommentItem> GetCommentItem(string id)
        {
            return Lookup(id);
        }

        // PATCH tables/CommentItem/48D68C86-6EA6-4C25-AA33-223FC9A27959
        public Task<CommentItem> PatchCommentItem(string id, Delta<CommentItem> patch)
        {
             return UpdateAsync(id, patch);
        }

        // POST tables/CommentItem
        public async Task<IHttpActionResult> PostCommentItem(CommentItem item)
        {
            CommentItem current = await InsertAsync(item);

            // Get the settings for the server project.
            HttpConfiguration config = this.Configuration;
            MobileAppSettingsDictionary settings =
                this.Configuration.GetMobileAppSettingsProvider().GetMobileAppSettings();

            // Get the Notification Hubs credentials for the Mobile App.
            string notificationHubName = settings.NotificationHubName;
            string notificationHubConnection = settings
                .Connections[MobileAppSettingsKeys.NotificationHubConnectionString].ConnectionString;

            // Create a new Notification Hub client.
            NotificationHubClient hub = NotificationHubClient
            .CreateClientFromConnectionString(notificationHubConnection, notificationHubName);

            // Define a WNS payload
            var windowsToastPayload = @"<toast><visual><binding template=""ToastText01""><text id=""1"">" + item.Name + @" posted a new comment : """
                                    + item.Description + @"""</text></binding></visual></toast>";

            try
            {
                // Send the push notification and log the results.
                var result = await hub.SendWindowsNativeNotificationAsync(windowsToastPayload);

                // Write the success result to the logs.
                config.Services.GetTraceWriter().Info(result.State.ToString());
            }
            catch (System.Exception ex)
            {
                // Write the failure result to the logs.
                config.Services.GetTraceWriter()
                    .Error(ex.Message, null, "Push.SendAsync Error");
            }

            return CreatedAtRoute("Tables", new { id = current.Id }, current);
        }

        // DELETE tables/CommentItem/48D68C86-6EA6-4C25-AA33-223FC9A27959
        public Task DeleteCommentItem(string id)
        {
             return DeleteAsync(id);
        }

    }
}