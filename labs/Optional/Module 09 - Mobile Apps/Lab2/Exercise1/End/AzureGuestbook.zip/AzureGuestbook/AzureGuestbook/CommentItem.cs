﻿
using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace AzureGuestbook
{
    public class CommentItem
    {
        public string Id { get; set; }

        [JsonProperty(PropertyName = "Description")]
        public string Description { get; set; }

        [JsonProperty(PropertyName = "Name")]
        public string Name { get; set; }
    }
}

